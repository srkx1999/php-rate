<?php

session_start();

function getrating($star)
{
    if ($star == 5) {
        ?>
        <table>
            <tr>
                <td>
                    <img height="25px" width="25px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="35px" width="35px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="50px" width="50px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="35px" width="35px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="25px" width="25px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
            </tr>
        </table>
    <?php
} elseif ($star == 4) {
    ?>
        <table>
            <tr>
                <td>
                    <img height="25px" width="25px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="35px" width="35px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="50px" width="50px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="35px" width="35px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="25px" width="25px" src="https://img.icons8.com/ios/26/000000/star.png">
                </td>
            </tr>
        </table>
    <?php
} elseif ($star == 3) {
    ?>
        <table>
            <tr>
                <td>
                    <img height="25px" width="25px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="35px" width="35px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="50px" width="50px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="35px" width="35px" src="https://img.icons8.com/ios/26/000000/star.png">
                </td>
                <td>
                    <img height="25px" width="25px" src="https://img.icons8.com/ios/26/000000/star.png">
                </td>
            </tr>
        </table>
    <?php
} elseif ($star == 2) {
    ?>
        <table>
            <tr>
                <td>
                    <img height="25px" width="25px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="35px" width="35px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="50px" width="50px" src="https://img.icons8.com/ios/26/000000/star.png">
                </td>
                <td>
                    <img height="35px" width="35px" src="https://img.icons8.com/ios/26/000000/star.png">
                </td>
                <td>
                    <img height="25px" width="25px" src="https://img.icons8.com/ios/26/000000/star.png">
                </td>
            </tr>
        </table>
    <?php
} elseif ($star == 1) {
    ?>
        <table>
            <tr>
                <td>
                    <img height="25px" width="25px" src="https://img.icons8.com/color/48/000000/christmas-star.png">
                </td>
                <td>
                    <img height="35px" width="35px" src="https://img.icons8.com/ios/26/000000/star.png">
                </td>
                <td>
                    <img height="50px" width="50px" src="https://img.icons8.com/ios/26/000000/star.png">
                </td>
                <td>
                    <img height="35px" width="35px" src="https://img.icons8.com/ios/26/000000/star.png">
                </td>
                <td>
                    <img height="25px" width="25px" src="https://img.icons8.com/ios/26/000000/star.png">
                </td>
            </tr>
        </table>
    <?php
}
}

$topmovie = array();
$topliked = array();
$gross = array();

try {
    $dbhandler = new PDO('mysql:host=127.0.0.1;dbname=mdb', 'srk', 'srk');
    $dbhandler->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    //Top Rating Array Generaton
    for ($i = 0; $i < 5; $i++) {
        $query = $dbhandler->query("select Movie_Id,Title,Score,Stars,Poster from movies ORDER BY Top ASC");
        $result = $query->fetchAll(PDO::FETCH_ASSOC);
        array_push($topmovie, $result[$i]);
    }

    //Most Liked Array Generaton
    for ($i = 0; $i < 5; $i++) {
        $query = $dbhandler->query("select Movie_Id,Title,Likes,Poster from movies ORDER BY Likes DESC");
        $result = $query->fetchAll(PDO::FETCH_ASSOC);
        array_push($topliked, $result[$i]);
    }

    //High Grossed Array Generation
    for ($i = 0; $i < 5; $i++) {
        $query = $dbhandler->query("select Movie_Id,Title,Gross,Poster from movies ORDER BY Gross DESC");
        $result = $query->fetchAll(PDO::FETCH_ASSOC);
        array_push($gross, $result[$i]);
    }
} catch (PDOException $e) {
    echo $e;
    die();
}

function getlike($likes)
{
    if ($likes > 1000000) {
        $likes = $likes / 1000000;
        return (string)(round($likes, 2)) . "M";
    } elseif ($likes > 1000) {
        $likes = $likes / 1000;
        return (string)(round($likes, 2)) . "K";
    } else {
        return $likes;
    }
}

function getgross($gross)
{
    if ($gross > 1000000000) {
        $gross = $gross / 1000000000;
        return "$" . (string)(round($gross, 2)) . " B";
    }
    elseif ($gross > 1000000) {
        $gross = $gross / 1000000;
        return "$" . (string)(round($gross, 2)) . " M";
    } elseif ($gross > 1000) {
        $gross = $gross / 1000;
        return "   $" . (string)(round($gross, 2)) . " K";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Medate</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <link rel="stylesheet" href="css/swiper.min.css">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/main.css">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700|Open+Sans:300,400,700" rel="stylesheet">
</head>

<body>
    <header class="hero">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-6 col-xs-12">
                    <nav>
                        <ul style="float:right;color:white;">
                            <table>
                                <tr>
                                    <td style="padding:9px;">
                                        <li><a href="index.php">
                                                <p style="color:white;">Home<p>
                                            </a></li>
                                    </td>
                                    <td style="padding:9px;">
                                        <li><a href="tvshow.php">
                                                <p style="color:white;">TV Shows<p>
                                            </a></li>
                                    </td>
                                    <td style="padding:9px;">
                                        <li><a href="music.php">
                                                <p style="color:white;">Music<p>
                                            </a></li>
                                    </td>
                                    <?php
                                    if (isset($_SESSION['user'])) {
                                        $user = $_SESSION['user'];
                                        ?>

                                        <td style="padding:9px;">
                                            <li><a href="profile.php">
                                                    <p class="auth" style="font-weight:800;color:white; border:3px solid white;padding:10px;"><?php echo $user; ?><p>
                                                </a></li>
                                        </td>
                                        <td style="padding:9px;">
                                            <li><a href="index.php">
                                                    <form method="POST" action="index.php">
                                                        <p class="auth"><button type="submit" name="logout" style="font-weight:800; color:black; padding:10px; background-color: transparent; border: 3px solid white; color: white; padding: 10px 22px; text-align: center; text-decoration: none; display: inline-block; font-size: 16px;">
                                                                LogOut
                                                            </button></p>
                                                    </form>

                                                </a></li>
                                        </td>
                                    <?php
                                } else {
                                    ?>
                                        <td style="padding:9px;">
                                            <li><a href="login.php">
                                                    <p class="auth" style="color:white; border:3px solid white;padding:5px;">Login<p>
                                                </a></li>
                                        </td>
                                        <td style="padding:9px;">
                                            <li><a href="register.php">
                                                    <p class="auth" style="color:white; border:3px solid white;padding:5px;">Register<p>
                                                </a></li>
                                        </td>
                                    </tr>
                                <?php
                            } ?>
                                </tr>
                            </table>
                        </ul>
                    </nav>


                    <div class="hero-text">
                        <h1 style="border-bottom:3px solid white;">Movies</h1>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <section class="">
        <div class="">
            <h1 class="heading blue" style="padding-left:50px;"><span class="blue">Top</span><br>Rated</h1>
            <div style="padding:10px;">
                <div class="row">

                    <?php
                    for ($i = 0; $i < 5; $i++) { ?>

                        <a href="/med/moviedetail.php?id=<?php echo $topmovie[$i]["Movie_Id"] ?>">
                            <div class="column">
                                <div class="card cardo">
                                    <h2 class="heading blue"></h2>
                                    <img src=<?php echo $topmovie[$i]["Poster"] ?> />
                                    <center>
                                        <h3 class=""><?php echo $topmovie[$i]["Title"] ?></h3>
                                        <br>
                                        <p class="">
                                            <h3><b><?php echo $topmovie[$i]["Score"] ?></b>/10</h3>
                                        </p>
                                        <?php
                                        getrating($topmovie[$i]["Stars"])
                                        ?>
                                        <br>
                                    </center>
                                </div>
                            </div>
                        </a>
                    <?php
                } ?>
                </div>
            </div>
        </div>
        <div class="">
            <h1 class="heading blue" style="padding-left:50px;"><span class="blue">Most</span><br>Liked</h1>
            <div style="padding:10px;">
                <div class="row">

                    <?php
                    for ($i = 0; $i < 5; $i++) { ?>
                        <a href="/med/moviedetail.php?id=<?php echo $topliked[$i]["Movie_Id"] ?>">
                            <div class="column">
                                <div class="card cardo">
                                    <h2 class="heading blue"></h2>
                                    <img src=<?php echo $topliked[$i]["Poster"] ?> />
                                    <center>
                                        <h3 class=""><?php echo $topliked[$i]["Title"] ?></h3>
                                        <br>
                                        <img height="55px" width="55px" src="https://img.icons8.com/flat_round/64/000000/hearts.png" />
                                        <br>
                                        <h3><b><?php echo getlike($topliked[$i]["Likes"]) ?></b></h3>
                                        <br>
                                    </center>
                                </div>
                            </div>
                        </a>
                    <?php
                } ?>
                </div>
            </div>
        </div>
        <div class="">
            <h1 class="heading blue" style="padding-left:50px;"><span class="blue">Highest Grossing</span><br>2019</h1>
            <div style="padding:10px;">
                <div class="row">
                    <?php
                    for ($i = 0; $i < 5; $i++) { ?>
                        <a href="/med/moviedetail.php?id=<?php echo $gross[$i]["Movie_Id"] ?>">
                            <div class="column">
                                <div class="card cardo">
                                    <h2 class="heading blue"></h2>
                                    <img src=<?php echo $gross[$i]["Poster"] ?> />
                                    <center>
                                        <h3 class=""><?php echo $gross[$i]["Title"] ?></h3>
                                        <br>
                                        <h3>WorlWide Gross<b><br><?php echo getgross($gross[$i]["Gross"]) ?></b></h3>
                                        <br>
                                    </center>
                                </div>
                            </div>
                        </a>
                    <?php
                } ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer -->
    <footer>
        <div class="container-fluid">
            <div class="row footer">
                <div class="col-md-12 text-center">
                    <h1>SRK<br><span>Inc.</span></h1>
                    <ul class="social-links">
                        <li><a href="#"><img src="assets/twitter.png"></a></li>
                        <li><a href="#"><img src="assets/github.png"></a></li>
                    </ul>
                </div>
            </div>
            <div class="row sub-footer">
                <div class="col-md-12 text-center">
                    <p>Copyright@2019. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>


    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/swiper.jquery.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
</body>

</html>