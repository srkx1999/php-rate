<?php

session_start();

try {
    $dbhandler = new PDO('mysql:host=127.0.0.1;dbname=mdb', 'srk', 'srk');
    $id = $_GET['id'];
    $dbhandler->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $query = $dbhandler->query("select * from musics where Music_Id='$id'");
    $result = $query->fetchAll(PDO::FETCH_ASSOC);
    $detail = $result[0];
    $trailer = $detail["Song"];
    $trend = $detail["Top"];
    $name = $detail["Title"];
    $query = $dbhandler->query("select Person_Id from music_person where Music_Id='$id'");
    $result = $query->fetchAll(PDO::FETCH_ASSOC);
    $pid = $result[0]["Person_Id"];
    $query = $dbhandler->query("select Name from person where Person_Id='$pid'");
    $result = $query->fetchAll(PDO::FETCH_ASSOC);
    $sub = $result[0]["Name"];


    $likes = $detail["Likes"];
    if ($likes > 1000000) {
        $likes = $likes / 1000000;
        $likes = (string)(round($likes, 2)) . "M";
    } elseif ($likes > 1000) {
        $likes = $likes / 1000;
        $likes = (string)(round($likes, 2)) . "K";
    }
    $streams = $detail["Totel_Stream"];
    if ($streams > 1000000000) {
        $streams = $streams / 1000000000;
        $streams = (string)(round($streams, 2)) . " B";
    } elseif ($streams > 1000000) {
        $streams = $streams / 1000000;
        $streams = (string)(round($streams, 2)) . " M";
    }
    $views = $detail["Youtub_Views"];
    if ($views > 1000000000) {
        $views = $views / 1000000000;
        $views = (string)(round($views, 2)) . " B";
    } elseif ($views > 1000000) {
        $views = $views / 1000000;
        $views = (string)(round($views, 2)) . " M";
    }
} catch (PDOException $e) {
    echo $e;
    die();
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Medate</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <link rel="stylesheet" href="css/swiper.min.css">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700|Open+Sans:300,400,700" rel="stylesheet">
</head>

<body>
    <header class="hero">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-6 col-xs-12">
                    <nav>
                        <ul style="float:right;color:white;">
                            <table>
                                <tr>
                                    <td style="padding:9px;">
                                        <li><a href="index.php">
                                                <p style="color:white;">Home<p>
                                            </a></li>
                                    </td>
                                    <td style="padding:9px;">
                                        <li><a href="movie.php">
                                                <p style="color:white;">Movies<p>
                                            </a></li>
                                    </td>
                                    <td style="padding:9px;">
                                        <li><a href="movie.php">
                                                <p style="color:white;">TV Shows<p>
                                            </a></li>
                                    </td>
                                    <td style="padding:9px;">
                                        <li><a href="music.php">
                                                <p style="color:white;">Music<p>
                                            </a></li>
                                    </td>
                                    <?php
                                    if (isset($_SESSION['user'])) {
                                        $user = $_SESSION['user'];
                                        ?>

                                        <td style="padding:9px;">
                                            <li><a href="profile.php">
                                                    <p class="auth" style="font-weight:800;color:white; border:3px solid white;padding:10px;"><?php echo $user; ?><p>
                                                </a></li>
                                        </td>
                                        <td style="padding:9px;">
                                            <li><a href="index.php">
                                                    <form method="POST" action="index.php">
                                                        <p class="auth"><button type="submit" name="logout" style="font-weight:800; color:black; padding:10px; background-color: transparent; border: 3px solid white; color: white; padding: 10px 22px; text-align: center; text-decoration: none; display: inline-block; font-size: 16px;">
                                                                LogOut
                                                            </button></p>
                                                    </form>

                                                </a></li>
                                        </td>
                                    <?php
                                } else {
                                    ?>
                                        <td style="padding:9px;">
                                            <li><a href="login.php">
                                                    <p class="auth" style="color:white; border:3px solid white;padding:5px;">Login<p>
                                                </a></li>
                                        </td>
                                        <td style="padding:9px;">
                                            <li><a href="register.php">
                                                    <p class="auth" style="color:white; border:3px solid white;padding:5px;">Register<p>
                                                </a></li>
                                        </td>
                                    </tr>
                                <?php
                            } ?>
                                </tr>
                            </table>
                        </ul>
                    </nav>


                    <div class="" style="padding-top:80px;">
                        <h1 class=" " style="padding-left:50px; "><span class=""><?php echo $name ?></span><br>
                            <p style="border-bottom:0px solid white;"><?php echo $sub ?></p>
                        </h1>
                    </div>

                </div>
            </div>
        </div>
    </header>

    <section class="hero-text">
        <div class="row" style="padding-top:30px;">
            <div class="column1">
                <div class="trailer" style="">
                    <iframe style="padding-left:30px;border:none;border-radius:50px;" width="98%" height="600px" src="https://www.youtube.com/embed/<?php echo $trailer ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div>
                        <?php
                        if (!isset($_SESSION['user'])) {
                            ?><center>
                                <h1 class="heading blue" style="padding-top:30px;"><span class="blue">You Need to <a href="login.php" style="border:3px solid black;padding:5px;"><b>Login</b></a> To Give Review</span><br></h1>
                            </center>
                        <?php
                    } else { ?>
                            <div class="giverev" id="myDIV">
                                <h1 class="heading purple" style="padding-top:30px;padding-left:20px;"><span class="purple">Give Your</span><br>Review</h1>
                                <center>

                                    <!--  like   -->
                                    <h1 class="heading blue"><span class=" blue">Give</span><br>Like</h1>
                                    <img height="75px" width="75px" class="star" id="imageOne" onclick="liked()" src="https://png.pngtree.com/svg/20151119/72fac5878b.svg" />
                                    <h1 class="heading blue"><span class=" blue">Comment</span><br></h1>
                                    <div ng-app="myApp">
                                        <div>
                                            <textarea id="comment" name="review" placeholder="Comment   ">
                                                </textarea>
                                        </div>
                                    </div>
                                    <br>
                                    <form action="review.php" method="POST">
                                        <input type="hidden" name="title" id="title" />
                                        <input type="hidden" name="media" id="name" />
                                        <input type="hidden" name="id" id="id" />
                                        <input type="hidden" name="star" id="gotstar" />
                                        <input type="hidden" name="like" id="gotlike" />
                                        <input type="hidden" name="comment" id="gotcomment" />
                                        <button class="button button5" onclick="sendReview()" type="submit" name="submit1">Submit Review</button>
                                    </form>
                                    <br>
                                    <br>

                                </center>
                            </div>
                            <script src="//code.jquery.com/jquery-1.10.2.js"></script>
                            <script>
                                //Review Info
                                var likegot = 0;

                                function sendReview() {
                                    var id = "<?php echo $_GET["id"] ?>"
                                    var comment = document.getElementById("comment").value;
                                    document.getElementById("gotcomment").value = comment;
                                    document.getElementById("name").value = "music";
                                    document.getElementById("id").value = id;
                                    document.getElementById("title").value = "<?php echo $name ?>";
                                }

                                //like
                                var image = document.getElementById("imageOne");

                                function liked() {
                                    if (likegot == 0) {
                                        image.src = "https://img.icons8.com/flat_round/64/000000/hearts.png";
                                        likegot++;
                                        document.getElementById("gotlike").value = likegot;
                                    } else {
                                        likegot--;
                                        console.log("disliked");
                                        image.src = "https://png.pngtree.com/svg/20151119/72fac5878b.svg";
                                        document.getElementById("gotlike").value = likegot;

                                    }
                                }
                            </script>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <div class="column2">
                <center>

                    <div class="info" style="padding-top:0px;">
                        <h1 class="heading red" style="padding-top:30px;"><span class="blue">#<?php echo $trend ?></span> Trending</h1>
                        <br>
                        <p class="" style="font-size:35px; "><b>Total Online Streams</b> <span><br></span><?php echo $streams ?></p>
                        <p style="font-size:15px; ">(From Spotify,Apple Music and Sound Cloud)<p><br>
                                <img height="55px" width="55px" src="https://img.icons8.com/flat_round/64/000000/hearts.png" />
                                <h3><b><?php echo $likes ?></b></h3><br>
                                <img height="55px" width="55px" src="https://cdn4.iconfinder.com/data/icons/social-media-icons-the-circle-set/48/youtube_circle-512.png" />
                                <h3><b><?php echo $views ?> Views</b></h3>
                                <br>
                    </div>
                </center>
                <center>
                    <h1 class="heading blue" style="padding-top:30px;"><span class="blue">Comments</span><br></h1>
                </center>
                <?php
                $query = $dbhandler->query("select comment,user from commet_music  where Music_Id='$id'");
                $result = $query->fetchAll(PDO::FETCH_ASSOC);
                ?>
                <!--comments-->
                <div style="overflow-y:scroll;height:950px;">

                    <?php for ($i = 0; $i < count($result); $i++) { ?>
                        <div class="w3-panel w3-light-grey" style="padding-top:20px;">
                            <span style="font-size:100px;line-height:0.6em;opacity:0.2;">❝</span>
                            <p class="" style="margin-top:-40px;font-size:30px;"><i><?php echo $result[$i]["comment"] ?></i></p>
                            <h2 style="float:right;padding-right:100px;">- <?php echo $result[$i]["user"] ?></h2>
                        </div><?php } ?>
                </div>
                <style>
                    a {
                        color: #333;
                        text-decoration: none;
                    }

                    h1,
                    h2,
                    h3 {
                        font-weight: 400;
                    }

                    h1 {
                        font-size: 30px;
                    }

                    h2 {
                        font-size: 24px;
                    }

                    h3 {
                        font-size: 20px;
                    }

                    section {
                        padding: 30px 60px;
                    }
                </style>
            </div>
        </div>

    </section>
    <!-- Footer -->
    <footer>
        <div class="container-fluid">
            <div class="row footer">
                <div class="col-md-12 text-center">
                    <h1>SRK<br><span>Inc.</span></h1>
                    <ul class="social-links">
                        <li><a href="#"><img src="assets/twitter.png"></a></li>
                        <li><a href="#"><img src="assets/github.png"></a></li>
                    </ul>
                </div>
            </div>
            <div class="row sub-footer">
                <div class="col-md-12 text-center">
                    <p>Copyright@2019. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>


    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/swiper.jquery.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>

    <style>
        .rating {
            display: inline-block;
            position: relative;
            height: 50px;
            line-height: 50px;
            font-size: 50px;
        }

        .rating label {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            cursor: pointer;
        }

        .rating label:last-child {
            position: static;
        }

        .rating label:nth-child(1) {
            z-index: 5;
        }

        .rating label:nth-child(2) {
            z-index: 4;
        }

        .rating label:nth-child(3) {
            z-index: 3;
        }

        .rating label:nth-child(4) {
            z-index: 2;
        }

        .rating label:nth-child(5) {
            z-index: 1;
        }

        .rating label input {
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0;
        }

        .rating label .icon {
            float: left;
            color: transparent;
        }

        .rating label:last-child .icon {
            color: #000;
        }

        .rating:not(:hover) label input:checked~.icon,
        .rating:hover label:hover input~.icon {
            color: #09f;
        }

        .rating label input:focus:not(:checked)~.icon:last-child {
            color: #000;
            text-shadow: 0 0 5px #09f;
        }
    </style>
</body>

</html>